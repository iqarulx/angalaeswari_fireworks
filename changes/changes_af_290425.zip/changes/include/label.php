<?php

$GLOBALS['delivery_slip_table'] = $GLOBALS['table_prefix'].'delivery_slip';
$GLOBALS['estimate_table'] = $GLOBALS['table_prefix'].'estimate';