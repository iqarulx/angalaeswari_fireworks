-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2025 at 12:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `angalaeswari_fireworks_16042025`
--

-- --------------------------------------------------------

--
-- Table structure for table `af_delivery_slip`
--

DROP TABLE IF EXISTS `af_delivery_slip`;

CREATE TABLE `af_delivery_slip` (
  `id` int(100) NOT NULL,
  `created_date_time` datetime NOT NULL,
  `creator` mediumtext NOT NULL,
  `creator_name` mediumtext NOT NULL,
  `bill_company_id` mediumtext NOT NULL,
  `delivery_slip_id` mediumtext NOT NULL,
  `delivery_slip_number` mediumtext NOT NULL,
  `delivery_slip_date` mediumtext NOT NULL,
  `proforma_invoice_id` mediumtext NOT NULL,
  `proforma_invoice_number` mediumtext NOT NULL,
  `proforma_invoice_date` mediumtext NOT NULL,
  `customer_id` mediumtext NOT NULL,
  `customer_name_mobile_city` mediumtext NOT NULL,
  `customer_details` mediumtext NOT NULL,
  `agent_id` mediumtext NOT NULL,
  `agent_name_mobile_city` mediumtext NOT NULL,
  `agent_details` mediumtext NOT NULL,
  `transport_id` mediumtext NOT NULL,
  `bank_id` mediumtext NOT NULL,
  `magazine_type` mediumtext DEFAULT NULL,
  `magazine_id` mediumtext DEFAULT NULL,
  `gst_option` mediumtext NOT NULL,
  `address` mediumtext NOT NULL,
  `tax_option` mediumtext NOT NULL,
  `tax_type` mediumtext NOT NULL,
  `overall_tax` mediumtext NOT NULL,
  `company_state` mediumtext NOT NULL,
  `party_state` mediumtext NOT NULL,
  `product_id` mediumtext NOT NULL,
  `indv_magazine_id` mediumtext DEFAULT NULL,
  `product_name` mediumtext NOT NULL,
  `unit_type` mediumtext NOT NULL,
  `subunit_need` mediumtext NOT NULL,
  `content` mediumtext NOT NULL,
  `unit_id` mediumtext NOT NULL,
  `unit_name` mediumtext NOT NULL,
  `quantity` mediumtext NOT NULL,
  `rate` mediumtext NOT NULL,
  `per` mediumtext NOT NULL,
  `per_type` mediumtext NOT NULL,
  `product_tax` mediumtext NOT NULL,
  `final_rate` mediumtext NOT NULL,
  `amount` mediumtext NOT NULL,
  `other_charges_id` mediumtext NOT NULL,
  `charges_type` mediumtext NOT NULL,
  `other_charges_value` mediumtext NOT NULL,
  `agent_commission` mediumtext NOT NULL,
  `bill_total` mediumtext NOT NULL,
  `cancelled` int(100) NOT NULL,
  `deleted` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `af_estimate`
--

DROP TABLE IF EXISTS `af_estimate`;

CREATE TABLE `af_estimate` (
  `id` int(100) NOT NULL,
  `created_date_time` datetime NOT NULL,
  `creator` mediumtext NOT NULL,
  `creator_name` mediumtext NOT NULL,
  `bill_company_id` mediumtext NOT NULL,
  `estimate_id` mediumtext NOT NULL,
  `estimate_number` mediumtext NOT NULL,
  `estimate_date` mediumtext NOT NULL,
  `delivery_slip_id` mediumtext NOT NULL,
  `delivery_slip_number` mediumtext NOT NULL,
  `delivery_slip_date` mediumtext NOT NULL,
  `customer_id` mediumtext NOT NULL,
  `customer_name_mobile_city` mediumtext NOT NULL,
  `customer_details` mediumtext NOT NULL,
  `agent_id` mediumtext NOT NULL,
  `agent_name_mobile_city` mediumtext NOT NULL,
  `agent_details` mediumtext NOT NULL,
  `transport_id` mediumtext NOT NULL,
  `bank_id` mediumtext NOT NULL,
  `magazine_type` mediumtext DEFAULT NULL,
  `magazine_id` mediumtext DEFAULT NULL,
  `gst_option` mediumtext NOT NULL,
  `address` mediumtext NOT NULL,
  `tax_option` mediumtext NOT NULL,
  `tax_type` mediumtext NOT NULL,
  `overall_tax` mediumtext NOT NULL,
  `company_state` mediumtext NOT NULL,
  `party_state` mediumtext NOT NULL,
  `product_id` mediumtext NOT NULL,
  `indv_magazine_id` mediumtext DEFAULT NULL,
  `product_name` mediumtext NOT NULL,
  `unit_type` mediumtext NOT NULL,
  `subunit_need` mediumtext NOT NULL,
  `content` mediumtext NOT NULL,
  `unit_id` mediumtext NOT NULL,
  `unit_name` mediumtext NOT NULL,
  `quantity` mediumtext NOT NULL,
  `rate` mediumtext NOT NULL,
  `per` mediumtext NOT NULL,
  `per_type` mediumtext NOT NULL,
  `product_tax` mediumtext NOT NULL,
  `final_rate` mediumtext NOT NULL,
  `amount` mediumtext NOT NULL,
  `other_charges_id` mediumtext NOT NULL,
  `charges_type` mediumtext NOT NULL,
  `other_charges_value` mediumtext NOT NULL,
  `agent_commission` mediumtext NOT NULL,
  `sub_total` mediumtext DEFAULT NULL,
  `grand_total` mediumtext DEFAULT NULL,
  `cgst_value` mediumtext DEFAULT NULL,
  `sgst_value` mediumtext DEFAULT NULL,
  `igst_value` mediumtext DEFAULT NULL,
  `total_tax_value` mediumtext DEFAULT NULL,
  `round_off` mediumtext DEFAULT NULL,
  `other_charges_total` mediumtext DEFAULT NULL,
  `bill_total` mediumtext NOT NULL,
  `cancelled` int(100) NOT NULL,
  `deleted` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `af_proforma_invoice`
--

DROP TABLE IF EXISTS `af_proforma_invoice`;

CREATE TABLE `af_proforma_invoice` (
  `id` int(100) NOT NULL,
  `created_date_time` datetime NOT NULL,
  `creator` mediumtext NOT NULL,
  `creator_name` mediumtext NOT NULL,
  `bill_company_id` mediumtext NOT NULL,
  `proforma_invoice_id` mediumtext NOT NULL,
  `proforma_invoice_number` mediumtext NOT NULL,
  `proforma_invoice_date` mediumtext NOT NULL,
  `customer_id` mediumtext NOT NULL,
  `customer_name_mobile_city` mediumtext NOT NULL,
  `customer_details` mediumtext NOT NULL,
  `agent_id` mediumtext NOT NULL,
  `agent_name_mobile_city` mediumtext NOT NULL,
  `agent_details` mediumtext NOT NULL,
  `transport_id` mediumtext NOT NULL,
  `bank_id` mediumtext NOT NULL,
  `gst_option` mediumtext NOT NULL,
  `address` mediumtext NOT NULL,
  `tax_option` mediumtext NOT NULL,
  `tax_type` mediumtext NOT NULL,
  `overall_tax` mediumtext NOT NULL,
  `company_state` mediumtext NOT NULL,
  `party_state` mediumtext NOT NULL,
  `product_id` mediumtext NOT NULL,
  `indv_magazine_id` mediumtext DEFAULT NULL,
  `product_name` mediumtext NOT NULL,
  `unit_type` mediumtext NOT NULL,
  `subunit_need` mediumtext NOT NULL,
  `content` mediumtext NOT NULL,
  `unit_id` mediumtext NOT NULL,
  `unit_name` mediumtext NOT NULL,
  `quantity` mediumtext NOT NULL,
  `rate` mediumtext NOT NULL,
  `per` mediumtext NOT NULL,
  `per_type` mediumtext NOT NULL,
  `product_tax` mediumtext NOT NULL,
  `final_rate` mediumtext NOT NULL,
  `amount` mediumtext NOT NULL,
  `other_charges_id` mediumtext NOT NULL,
  `charges_type` mediumtext NOT NULL,
  `other_charges_value` mediumtext NOT NULL,
  `agent_commission` mediumtext NOT NULL,
  `sub_total` mediumtext DEFAULT NULL,
  `grand_total` mediumtext DEFAULT NULL,
  `cgst_value` mediumtext DEFAULT NULL,
  `sgst_value` mediumtext DEFAULT NULL,
  `igst_value` mediumtext DEFAULT NULL,
  `total_tax_value` mediumtext DEFAULT NULL,
  `round_off` mediumtext DEFAULT NULL,
  `other_charges_total` mediumtext DEFAULT NULL,
  `bill_total` mediumtext NOT NULL,
  `cancelled` int(100) NOT NULL,
  `deleted` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `af_delivery_slip`
--
ALTER TABLE `af_delivery_slip`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `af_estimate`
--
ALTER TABLE `af_estimate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `af_proforma_invoice`
--
ALTER TABLE `af_proforma_invoice`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `af_delivery_slip`
--
ALTER TABLE `af_delivery_slip`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `af_estimate`
--
ALTER TABLE `af_estimate`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `af_proforma_invoice`
--
ALTER TABLE `af_proforma_invoice`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
