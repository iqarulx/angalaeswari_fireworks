<?php

/** Replace function */

public function UpdateBalance($bill_id,$bill_number,$bill_date,$bill_type,$agent_id,$agent_name,$party_id,$party_name,$party_type,$payment_mode_id,$payment_mode_name,$bank_id,$bank_name,$credit,$debit,$open_balance_type){
    $query = ""; $list = array(); $unique_id = "";

    if($bill_type == "Voucher" || $bill_type == "Receipt" || $bill_type == "Expense" || $bill_type == "Suspense Voucher" || $bill_type == "Suspense Receipt"){
        $query = "SELECT id FROM ".$GLOBALS['payment_table']." WHERE bill_id = '".$bill_id."' AND payment_mode_id = '".$payment_mode_id."' AND bank_id = '". $bank_id."' AND deleted = '0'";
    } else {
        if(!empty($agent_id)) {
            $query = "SELECT id FROM " . $GLOBALS['payment_table'] . " WHERE bill_id = '" . $bill_id . "' AND agent_id = '" . $agent_id . "' AND deleted = '0'";
        } else {
            $query = "SELECT id FROM " . $GLOBALS['payment_table'] . " WHERE bill_id = '" . $bill_id . "' AND deleted = '0'";
        }
    }

    $list = $this->getQueryRecords('', $query);
    if(!empty($list)) {
        foreach($list as $data) {
            if(!empty($data['id']) && $data['id'] != $GLOBALS['null_value']) {
                $unique_id = $data['id'];
            }
        }
    }

    $created_date_time = $GLOBALS['create_date_time_label'];
    $creator = $GLOBALS['creator'];
    $creator_name = $GLOBALS['creator_name'];
    if(preg_match("/^\d+$/", $unique_id)) {
        $action = "Updated Successfully";
        $columns = array(); $values = array();
        $columns = array('creator_name','bill_date', 'agent_id','agent_name', 'party_id','party_name','party_type','bank_id','bank_name','payment_mode_id','payment_mode_name','open_balance_type','credit','debit');
        $values = array("'".$creator_name."'","'".$bill_date."'", "'".$agent_id."'","'".$agent_name."'", "'".$party_id."'","'".$party_name."'","'".$party_type."'","'".$bank_id."'","'".$bank_name."'","'".$payment_mode_id."'","'".$payment_mode_name."'","'".$open_balance_type."'","'".$credit."'","'".$debit."'");
        $payment_update_id = $this->UpdateSQL($GLOBALS['payment_table'], $unique_id, $columns, $values, $action);
    }
    else {
        $action = "Inserted Successfully";
        $null_value = $GLOBALS['null_value'];
        $columns = array(); $values = array();
        $columns = array('created_date_time','creator', 'creator_name', 'bill_id','bill_number','bill_date','bill_type', 'agent_id','agent_name', 'party_id','party_name','party_type','bank_id','bank_name','payment_mode_id','payment_mode_name','open_balance_type', 'credit','debit','deleted');
        $values = array("'".$created_date_time."'", "'".$creator."'", "'".$creator_name."'", "'".$bill_id."'","'".$bill_number."'","'".$bill_date."'","'".$bill_type."'", "'".$agent_id."'","'".$agent_name."'", "'".$party_id."'","'".$party_name."'","'".$party_type."'","'".$bank_id."'","'".$bank_name."'","'".$payment_mode_id."'","'".$payment_mode_name."'", "'".$open_balance_type."'", "'".$credit."'","'".$debit."'","'0'");
        $payment_insert_id = $this->InsertSQL($GLOBALS['payment_table'], $columns, $values, '', '', $action);
    }
}