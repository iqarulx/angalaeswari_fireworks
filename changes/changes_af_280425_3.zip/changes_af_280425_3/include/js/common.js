/** Update Function */

function ShowConversion(conversion_id, page_title) {
    if (page_title == 'Proforma Invoice') {
        var post_url = "delivery_slip_changes.php?show_delivery_slip_id=" + conversion_id + "&conversion_update=1";
    } else if (page_title == 'Delivery Slip') {
        var post_url = "estimate_changes.php?show_estimate_id=" + conversion_id + "&conversion_update=1";
    }
    jQuery.ajax({
        url: post_url, success: function (result) {
            if (jQuery('#table_records_cover').length > 0) {
                jQuery('#table_records_cover').addClass('d-none');
            }
            if (jQuery('#add_update_form_content').length > 0) {
                jQuery('#add_update_form_content').removeClass('d-none');
            }
            if (jQuery('.add_update_form_content').length > 0) {
                jQuery('.add_update_form_content').html("");
                jQuery('.add_update_form_content').html(result);
            }

        }
    });
}