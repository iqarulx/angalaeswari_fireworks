<?php

// Function Added

public function getProfomaInvoiceList($from_date, $to_date, $customer_id, $search_text, $show_bill) {
	$list = array(); $select_query = ""; $where = "";

	if(!empty($from_date)) {
		$from_date = date("Y-m-d", strtotime($from_date));
		$where = "proforma_invoice_date >= '".$from_date."'";
	}
	if(!empty($to_date)) {
		$to_date = date("Y-m-d", strtotime($to_date));
		if(!empty($where)) {
			$where = $where." AND proforma_invoice_date <= '".$to_date."'";
		}
		else {
			$where = "proforma_invoice_date <= '".$to_date."'";
		}
	}
	if($show_bill == '0' || $show_bill == '1'){
		if(!empty($where)) {
			$where = $where." AND cancelled = '".$show_bill."' ";
		}
		else {
			$where = "cancelled = '".$show_bill."' ";
		}
	}

	if(!empty($customer_id)){
		if(!empty($where)) {
			$where = $where." AND customer_id = '".$customer_id."' ";
		} else {
			$where = "customer_id = '".$customer_id."' ";
		}
	}

	if(!empty($where)) {
		$select_query = "SELECT * FROM ".$GLOBALS['proforma_invoice_table']." WHERE ".$where." AND deleted = '0' ORDER BY id DESC";	
	}
	else{
		$select_query = "SELECT * FROM ".$GLOBALS['proforma_invoice_table']." WHERE cancelled = '0' AND deleted = '0' ORDER BY id DESC";
	}
	
	if(!empty($select_query)) {
		$list = $this->getQueryRecords($GLOBALS['proforma_invoice_table'], $select_query);
	}
	return $list;
}