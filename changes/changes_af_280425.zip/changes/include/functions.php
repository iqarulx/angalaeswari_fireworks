<?php

// Function Declaration Added

public function getProfomaInvoiceList($from_date, $to_date, $customer_id, $search_text,$show_bill) {
	$creationobj = "";
	$creationobj = $this->creation_function_object();
	$list = array();
	$list = $creationobj->getProfomaInvoiceList($from_date, $to_date, $customer_id, $search_text,$show_bill);
	return $list;
}