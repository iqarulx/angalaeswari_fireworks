<?php

// Function Changed
public function automate_number($table, $column) {
	$last_number = 0; $next_number = ""; $last_id_number = "";
	$prefix = "";
	// if(!empty($table) && $table == $GLOBALS['inward_entry_table']) {
	//     $prefix = 'INW';
	// }
	// else if(!empty($table) && $table == $GLOBALS['expense_table']) {
	//     $prefix = 'EXP';
	// }
	// else if(!empty($table) && $table == $GLOBALS['voucher_table']) {
	//     $prefix = 'VOC';
	// }
	// else if(!empty($table) && $table == $GLOBALS['receipt_table']) {
	//     $prefix = 'RCT';
	// }
	if(!empty($table) && $table == $GLOBALS['consumption_entry_table']) {
		$prefix = 'CON';
	}
	else if(!empty($table) && $table == $GLOBALS['daily_production_table']) {
		$prefix = 'DAP';
	}
	else if(!empty($table) && $table == $GLOBALS['proforma_invoice_table']) {
		$prefix = 'PI';
	}
	// else if(!empty($table) && $table == $GLOBALS['semifinished_inward_table']) {
	//     $prefix = 'SMI';
	// }
	// else if(!empty($table) && $table == $GLOBALS['material_transfer_table']) {
	//     $prefix = 'MAT';
	// }
	// else if(!empty($table) && $table == $GLOBALS['performa_invoice_table']) {
	//     $prefix = 'PI';
	// }
	// else if(!empty($table) && $table == $GLOBALS['estimate_table']) {
	//     $prefix = 'EST';
	// }
	// else if(!empty($table) && $table == $GLOBALS['sales_invoice_table']) {
	//     $prefix = 'SI';
	// }
	$current_year = date("y"); $next_year = date("y")+1;
	
	if(date("m") == date("01") || date("m") == date("02") || date("m") == date("03")) {
		$current_year = date("y") - 1; $next_year = date("y");
	}
	$select_query1 = "SELECT ".$column." as last_number FROM ".$table." where (".$column."!='".$GLOBALS['null_value']."' && ".$column."!='') ORDER BY created_date_time DESC LIMIT 1";
	if(!empty($select_query1)) {
		$automate_number_list = array();
		$automate_number_list = $this->getQueryRecords($table, $select_query1);
		if(!empty($automate_number_list)) {
			foreach($automate_number_list as $anumber) {
				if(!empty($anumber['last_number']) && $anumber['last_number'] != $GLOBALS['null_value']) {
					$last_number = $anumber['last_number'];
					$last_id_number = $anumber['last_number'];
				}
			}
		}
	}
	
	if(strpos($last_number, '/') !== false){
		$last_number_array = array();
		$last_number_array = explode("/", $last_number);
		$last_number = $last_number_array[0];
		$last_number = trim($last_number);
		if(!empty($prefix)){
			// if(!empty($table) && $table == $GLOBALS['inward_entry_table']) {
			//     $last_number = str_replace("INW","",$last_number);
			//     $last_number = trim($last_number);
			// }
			// else if(!empty($table) && $table == $GLOBALS['expense_table']) {
			//     $last_number = str_replace("EXP","",$last_number);
			//     $last_number = trim($last_number);
			// }
			// else if(!empty($table) && $table == $GLOBALS['voucher_table']) {
			//     $last_number = str_replace("VOC","",$last_number);
			//     $last_number = trim($last_number);
			// }
			// else if(!empty($table) && $table == $GLOBALS['receipt_table']) {
			//     $last_number = str_replace("RCT","",$last_number);
			//     $last_number = trim($last_number);
			// }
			if(!empty($table) && $table == $GLOBALS['consumption_entry_table']) {
				$last_number = str_replace("CON","",$last_number);
				$last_number = trim($last_number);
			}
			else if(!empty($table) && $table == $GLOBALS['daily_production_table']) {
				$last_number = str_replace("DAP","",$last_number);
				$last_number = trim($last_number);
			}
			else if(!empty($table) && $table == $GLOBALS['proforma_invoice_table']) {
				$last_number = str_replace("PI","",$last_number);
				$last_number = trim($last_number);
			}
			// else if(!empty($table) && $table == $GLOBALS['semifinished_inward_table']) {
			//     $last_number = str_replace("SMI","",$last_number);
			//     $last_number = trim($last_number);
			// }
			// else if(!empty($table) && $table == $GLOBALS['material_transfer_table']) {
			//     $last_number = str_replace("MAT","",$last_number);
			//     $last_number = trim($last_number);
			// }
			// else if(!empty($table) && $table == $GLOBALS['performa_invoice_table']) {
			//     $last_number = str_replace("PI","",$last_number);
			//     $last_number = trim($last_number);
			// }
			// else if(!empty($table) && $table == $GLOBALS['estimate_table']) {
			//     $last_number = str_replace("EST","",$last_number);
			//     $last_number = trim($last_number);
			// }
			// else if(!empty($table) && $table == $GLOBALS['sales_invoice_table']) {
			//     $last_number = str_replace("SI","",$last_number);
			//     $last_number = trim($last_number);
			// }
		}
		$next_number = $last_number + 1;
	}
	if(empty($last_number)){
		$next_number = 1;
	}
	if(!empty($next_number)) {
		if(date("m") == date("01") || date("m") == date("02") || date("m") == date("03")) {
			$current_year = date("y") - 1; $next_year = date("y");
		}
		if(date("d-m-Y") >= date("01-04-Y")) {
			if(strpos($last_id_number,($current_year.'-'.$next_year)) !== false){
				
			}
			else{
				$next_number = 1;
			}
		}
		if(strlen($next_number) == "1"){
			$next_number = '00'.$next_number;
		}
		else if(strlen($next_number) == "2"){
			$next_number = '0'.$next_number;
		}
		
		if(!empty($prefix)) {
			$next_number = $prefix.$next_number.'/'.$current_year.'-'.$next_year;
		}
		else{
			$next_number = $next_number.'/'.$current_year.'-'.$next_year;
		}
	}
	return $next_number;
}
