<?php

/* Line no 521 found error. Identification mismatch */

$prev_iden_customer_id = ""; $iden_customer_error = "";	$prev_iden_customer_name ="";

if(!empty($identification) && $identification != $GLOBALS['null_value']) {
    // $prev_customer_id = $obj->customeridentificationExists($identification);
    $prev_iden_customer_id = $obj->getTableColumnValue($GLOBALS['customer_table'], 'identification', $identification, 'customer_id');
    if(!empty($prev_iden_customer_id) && $prev_iden_customer_id != $edit_id) {
        $prev_iden_customer_name = $obj->getTableColumnValue($GLOBALS['customer_table'],'customer_id',$prev_iden_customer_id,'customer_name');
        if(!empty($prev_iden_customer_name)){
            $prev_iden_customer_name = $obj->encode_decode("decrypt",$prev_iden_customer_name);
            $iden_customer_error = "This Identification number is already exist in ".$prev_iden_customer_name;
        }
    }
}